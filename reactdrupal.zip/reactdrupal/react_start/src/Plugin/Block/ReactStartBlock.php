<?php

namespace Drupal\react_start\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'React Start' Block
 *
 * @Block(
 *   id = "react_start",
 *   admin_label = @Translation("React start block"),
 * )
 */
class ReactStartBlock extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {
        return [
            '#markup' => "
                <div id='react_start'></div>
                <div id='react_start_jsx'></div>
                <div id='react_start_api'></div>
            ",
            '#attached' => [
                'library' =>  [
                    'react_start/advanced'
                ],
            ],
        ];
    }
}
