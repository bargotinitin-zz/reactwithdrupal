ReactDOM.render(
  <h1> This text has been rendered from React JS. </h1>,
  document.getElementById('react-app')
);
